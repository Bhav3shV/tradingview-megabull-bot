"""
Test script to simulate TradingView Webhook Alerts with MegaBull integration.
"""

import time
import requests
import config

BASE_URL = f"http://127.0.0.1:{config.PORT}"

def run_tests():
    print("=" * 60)
    print("RUNNING MEGABULL TRADINGVIEW WEBHOOK BRIDGE TESTS")
    print("=" * 60)

    # 1. Health check
    try:
        resp = requests.get(f"{BASE_URL}/health", timeout=3)
        print(f"[TEST 1] Health Check: Status {resp.status_code} => {resp.json()}")
    except Exception as e:
        print(f"[TEST 1 FAILED] Server is not reachable at {BASE_URL}. Ensure webhook_bridge.py is running.")
        return

    # 2. Test Invalid Secret (Should reject with 401)
    bad_payload = {
        "secret": "wrong_password",
        "action": "buy",
        "symbol": "ETERNAL",
        "qty": 10
    }
    resp = requests.post(f"{BASE_URL}/webhook", json=bad_payload)
    print(f"[TEST 2] Unauthorized Alert Rejection: Status {resp.status_code} (Expected 401)")
    assert resp.status_code == 401, "Expected 401 Unauthorized"

    # 3. Test Buy Alert for ETERNAL (from TradingView Chart)
    buy_payload = {
        "secret": config.WEBHOOK_SECRET,
        "action": "buy",
        "symbol": "ETERNAL",
        "qty": 25,
        "sl": 315.00,
        "tp": 345.00,
        "duration": "MIS"
    }
    resp = requests.post(f"{BASE_URL}/webhook", json=buy_payload)
    print(f"[TEST 3] MegaBull Buy Alert: Status {resp.status_code} => {resp.json()}")
    assert resp.status_code == 200, "Expected 200 OK"

    time.sleep(1)

    # 4. Test Square-off / Close Position Alert
    close_payload = {
        "secret": config.WEBHOOK_SECRET,
        "action": "close",
        "symbol": "ETERNAL",
        "qty": 25
    }
    resp = requests.post(f"{BASE_URL}/webhook", json=close_payload)
    print(f"[TEST 4] MegaBull Close Alert: Status {resp.status_code} => {resp.json()}")
    assert resp.status_code == 200, "Expected 200 OK"

    print("=" * 60)
    print("ALL MEGABULL BRIDGE TESTS PASSED SUCCESSFULLY!")
    print("=" * 60)

if __name__ == "__main__":
    run_tests()
